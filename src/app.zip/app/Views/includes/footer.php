<footer class="bg-[#EFE7DD] text-[#8B5A2B] text-center py-4 left-0 w-full shadow-md relative mt-8" style="font-family: 'Cormorant Garamond', serif;">
    © 2025 Chic And Chill - Tous droits réservés.
</footer>
