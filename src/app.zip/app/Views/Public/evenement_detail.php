<?php
include('src/app/Views/includes/head.php');
include('src/app/Views/includes/header.php');

if (!isset($event) || !$event) {
    echo "<p class='text-center text-red-500'>Événement introuvable.</p>";
    include('src/app/Views/includes/footer.php');
    exit();
}
?>

<div class="container mx-auto my-8 px-4">
    <div class="max-w-2xl mx-auto bg-white shadow-lg rounded-lg p-6 border border-gray-200">
        <!-- Image de l'événement -->
        <img src="<?= BASE_URL ?>assets/images/events/<?= isset($event['image']) ? htmlspecialchars($event['image']) : 'placeholder.jpg' ?>" 
             alt="<?= htmlspecialchars($event['title']) ?>" 
             class="w-full h-64 object-cover rounded-md">

        <h2 class="text-3xl font-bold text-gray-800 mt-4"><?= htmlspecialchars($event['title']) ?></h2>
        <p class="text-gray-600 text-sm mt-2"><?= htmlspecialchars($event['description']) ?></p>

        <p class="text-gray-700 mt-4"><strong>Date :</strong> <?= htmlspecialchars($event['date_event']) ?> à <?= htmlspecialchars($event['time_event']) ?></p>
        <p class="text-gray-700"><strong>Lieu :</strong> <?= htmlspecialchars($event['location']) ?></p>

        <a href="../evenements" class="mt-6 inline-block px-4 py-2 bg-gray-500 text-white font-semibold rounded hover:bg-gray-600 transition duration-300">
            Retour aux événements
        </a>
    </div>
</div>

<?php include('src/app/Views/includes/footer.php'); ?>