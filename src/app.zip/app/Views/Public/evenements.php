<?php include('src/app/Views/includes/head.php'); ?>
<?php include('src/app/Views/includes/header.php'); ?>

<style>
    /* CARROUSEL IMMERSIF */
    .carousel-container {
        position: relative;
        width: 100%;
        height: 100vh;
        overflow: hidden;
    }
    .carousel-slide {
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: center;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .carousel-text {
        position: absolute;
        color: white;
        font-size: 4rem;
        font-weight: bold;
        text-shadow: 3px 3px 15px rgba(0, 0, 0, 0.7);
    }
</style>

<div class="carousel-container">
    <div class="carousel-slide" style="background-image: url('assets/images/events/event1.jpg');">
        <h1 class="carousel-text">Événements Chic & Chill</h1>
    </div>
</div>

<!-- GRILLE DES ÉVÉNEMENTS -->
<div class="container mx-auto px-4 py-8">
    <h2 class="text-4xl font-bold text-center text-gray-800 mb-8">Nos Événements</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($events as $event) : ?>
            <div class="bg-white shadow-lg rounded-lg overflow-hidden transform transition duration-500 hover:scale-105">
                <img src="<?= BASE_URL ?>assets/images/events/<?= htmlspecialchars($event['image']) ?>" class="w-full h-64 object-cover">
                <div class="p-6">
                    <h3 class="text-xl font-semibold text-gray-800 mb-2"> <?= htmlspecialchars($event['title']) ?> </h3>
                    <p class="text-gray-600"> <?= htmlspecialchars($event['description']) ?> </p>
                    <a href="evenement_detail.php?id=<?= $event['id'] ?>" class="inline-block mt-4 text-white bg-red-600 px-4 py-2 rounded-md transition duration-300 hover:bg-red-800">Voir Détails</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- PACKS & TENUES -->
<div class="container mx-auto px-4 py-16 bg-gray-100">
    <h2 class="text-3xl font-bold text-center text-gray-800 mb-8">Nos Packs & Idées de Tenues</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-white shadow-md rounded-lg p-6 transform transition duration-500 hover:scale-105">
            <h3 class="text-xl font-semibold text-gray-700 mb-4">Pack VIP</h3>
            <p class="text-gray-600">Accès exclusif, service premium et boissons incluses.</p>
        </div>
        <div class="bg-white shadow-md rounded-lg p-6 transform transition duration-500 hover:scale-105">
            <h3 class="text-xl font-semibold text-gray-700 mb-4">Idée de Tenue</h3>
            <p class="text-gray-600">Chic et décontracté : chemise en lin, pantalon beige, accessoires minimalistes.</p>
        </div>
    </div>
</div>

<?php include('src/app/Views/includes/footer.php'); ?>
