<?php
namespace Models;

class OutfitsModel
{
    private $outfits = [
        'mariage' => ['Robe élégante + accessoires', 'Costume chic + nœud papillon'],
        'bapteme' => ['Tenue blanche + chaussures assorties', 'Costume léger + sandales'],
        'soiree' => ['Robe de soirée + escarpins', 'Tenue de cocktail + accessoires']
    ];

    public function getSuggestionsByEvent($eventType)
    {
        return $this->outfits[$eventType] ?? [];
    }
}
?>
