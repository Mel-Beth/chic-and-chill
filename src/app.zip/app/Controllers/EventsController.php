<?php

namespace Controllers;

use Models\EventsModel;
use Models\OutfitsModel;
use Models\PacksModel;

class EventsController
{
    public function index()
    {
        try {
            $eventsModel = new EventsModel();
            $outfitsModel = new OutfitsModel();
            $packsModel = new PacksModel();

            $events = $eventsModel->getAllEvents();
            $pastEvents = $eventsModel->getPastEvents();
            $eventPacks = $packsModel->getAllPacks();

            // Génération des suggestions de tenues
            $suggestedOutfits = [];
            foreach ($events as $event) {
                $suggestedOutfits[$event['title']] = $outfitsModel->getSuggestionsByEvent($event['title']);
            }

            include('src/app/Views/Public/evenements.php');
        } catch (\Exception $e) {
            error_log($e->getMessage());
            echo "Une erreur est survenue. Veuillez réessayer plus tard.";
        }
    }

    public function showEvent($id)
    {
        try {
            $eventsModel = new EventsModel();
            $event = $eventsModel->getEventById($id);

            include('src/app/Views/Public/evenement_detail.php');
        } catch (\Exception $e) {
            error_log($e->getMessage());
            echo "Une erreur est survenue. Veuillez réessayer plus tard.";
        }
    }
}
