<footer>
    <p>&copy; 2024 - Chic & Chill. Tous droits reservés</p>
</footer>
</body>

</html>