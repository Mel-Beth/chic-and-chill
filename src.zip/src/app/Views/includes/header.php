<!-- HEADER -->
<header class="absolute top-0 left-0 w-full flex justify-between items-center px-10 py-4 bg-transparent">
        <!-- Logo -->
        <div class="text-yellow-500 font-bold text-3xl tracking-wide">
            CHIC <span class="text-white">AND</span> CHILL
        </div>

        <!-- Menu -->
        <nav class="hidden md:flex space-x-8 text-lg text-yellow-500 font-semibold">
            <a href="#" class="hover:text-white transition duration-300">Accueil</a>
            <a href="#" class="hover:text-white transition duration-300">Événements</a>
            <a href="#" class="hover:text-white transition duration-300">Location</a>
            <a href="#" class="hover:text-white transition duration-300">Magasin</a>
            <a href="#" class="hover:text-white transition duration-300">Contact</a>
        </nav>

        <!-- Menu mobile -->
        <div class="md:hidden">
            <button id="menu-toggle" class="text-yellow-500 focus:outline-none">
                ☰
            </button>
        </div>
    </header>