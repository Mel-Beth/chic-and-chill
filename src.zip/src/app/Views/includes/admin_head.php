<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="http://localhost/projets/projetsExo/chic-and-chill/">
    <!-- <base href="http://localhost/site_stage/chic-and-chill/"> -->
    <link href="src/css/output.css" rel="stylesheet">
    <link href="src/css/style.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script>
</head>