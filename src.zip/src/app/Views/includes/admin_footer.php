<footer class="bg-[#8B5A2B] text-white py-6 text-center mt-auto w-full">
    <p>© 2025 Chic & Chill - Administration | Tous droits réservés.</p>
</footer>
</html>
