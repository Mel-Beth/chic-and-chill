<!doctype html>
<html lang="fr">
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="src/css/output.css" rel="stylesheet">
  <link href="src/css/style.css" rel="stylesheet">
  <title>Chic and Chill</title>
</head>