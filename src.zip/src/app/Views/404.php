<?php include("src/app/Views/includes/head.php"); ?>
<?php include("src/app/Views/includes/header.php"); ?>

<div class="container">
    <h1>Erreur 404</h1>
    <p>La page que vous cherchez n'existe pas.</p>
    <p><a href="accueil">Retour à l'accueil</a></p>
</div>

<?php include("src/app/Views/includes/footer.php"); ?>