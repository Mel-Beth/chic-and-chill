<?php include("src/app/Views/includes/head.php"); ?>
<?php include("src/app/Views/includes/header.php"); ?>


<body class="bg-gray-900 flex justify-center items-center h-screen">

    <div class="relative w-full max-w-4xl">
        <!-- Image de fond -->
        <img src="assets/images/image_accueil.png" alt="Chic And Chill" class="w-full h-auto object-cover rounded-lg shadow-lg">

        <!-- Encadrement carré -->
        <div class="square top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2">
            <p class="text-yellow-500 font-bold text-4xl text-center leading-tight">
                CHIC <br> AND <br> CHILL
            </p>
        </div>

        <!-- Cercles décoratifs -->
        <div class="circle top-5 left-10"></div>
        <div class="circle top-5 right-10"></div>
        <div class="circle bottom-10 left-10"></div>

        <!-- Labels (Even, Location, Magasin) -->
        <span class="absolute top-8 left-14 text-yellow-500 font-bold text-lg">EVEN</span>
        <span class="absolute top-8 right-14 text-yellow-500 font-bold text-lg">LOCATION</span>
        <span class="absolute bottom-8 left-14 text-yellow-500 font-bold text-lg">MAGASIN</span>
    </div>

<?php include("src/app/Views/includes/footer.php"); ?>