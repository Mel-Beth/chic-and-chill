<!DOCTYPE html>
<html lang="fr">
<?php include('src/app/Views/includes/head_shop.php'); ?>
<body class="paiement_valid_body_shop">
<?php include('src/app/Views/includes/header_shop.php'); ?>

<section class="paiement_succes_shop">
    <h1>✅ Paiement Réussi</h1>
    <p>Merci pour votre achat !</p>
    <a href="accueil_shop">Retour à la boutique</a>
    </section>
    <?php include('src/app/Views/includes/footer_shop.php'); ?>
</body>
</html>
