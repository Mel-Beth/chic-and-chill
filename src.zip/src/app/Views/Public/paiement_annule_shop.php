<!DOCTYPE html>
<html lang="fr">
<?php include('src/app/Views/includes/head_shop.php'); ?>
<body>
<?php include('src/app/Views/includes/header_shop.php'); ?>
    <h1>❌ Paiement Annulé</h1>
    <p>Votre transaction a été annulée.</p>
    <a href="panier_shop">Retour au panier</a>
    <?php include('src/app/Views/includes/footer_shop.php'); ?>
</body>
</html>
