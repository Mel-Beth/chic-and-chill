<form action="forgot-password" method="POST">
    <label>Email</label>
    <input type="email" name="email" required>
    <button type="submit">Envoyer le lien</button>
</form>
